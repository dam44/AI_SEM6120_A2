﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TSPGenGUI.JSONOutput
{
    /// <summary>
    /// JSON Wrapper class.
    /// </summary>
    public class Wrapper
    {
        public List<Run> runs;
        public Overall overall;
        public Wrapper()
        {

        }


    }
}
