﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticAPI.Shared.Util
{
    public enum Randoms
    {
        Advanced = 0,
        Basic = 1,
    }
}
