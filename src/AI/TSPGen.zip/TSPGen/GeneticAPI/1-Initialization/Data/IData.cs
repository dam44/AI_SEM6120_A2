﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticAPI
{
    public interface IData
    {

        int x();
        int y();
        int id();

    }
}
