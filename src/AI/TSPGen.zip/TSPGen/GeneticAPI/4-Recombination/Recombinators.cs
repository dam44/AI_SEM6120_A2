﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticAPI.Recombination
{
    public enum Recombinators
    {
        OnePointCrossoverPMX = 1,
        TwoPointCrossoverPMX = 2,
    }
}
