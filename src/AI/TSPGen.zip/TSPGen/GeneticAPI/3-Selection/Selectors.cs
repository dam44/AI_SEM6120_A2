﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticAPI.Selection
{
    public enum Selectors
    {
        Tournament = 0,
        Roulette = 1,
        Rank = 2,

    }
}
